export const users = [
    {
      id: 1,
      name: "Leman Graham",
      username: "Bret",
      email: "bret@gmail.com",
      phone: "1-770-586589",
      website: "hildegard.org"
    },
    {
      id: 2,
      name: "Deo John",
      username: "Antonette",
      email: "anto@gmail.comUP",
      phone: "01-07-67878900",
      website: "antonette.net"
    },
    {
      id: 3,
      name: "Bauch Thomson",
      username: "Thomson",
      email: "thomson@yopmail.com",
      phone: "91-07-19189422",
      website: "thomson.org"
    },
    {
      id: 4,
      name: "Samanth Dev",
      username: "Devender",
      email: "devender@gmail.com",
      phone: "011-570-997857",
      website: "devender.co.in"
    },
    {
      id: 5,
      name: "Ankita Kumari",
      username: "Ankita",
      email: "ankita@gmail.com",
      phone: "1-45-253254",
      website: "ankita.org"
    },
    {
      id: 6,
      name: "Prajapati Kumar",
      username: "Prajapati",
      email: "prajapati@gmail.com",
      phone: "1-770-586589",
      website: "prajapati.org"
    },
    {
      id: 7,
      name: "Kumari Rupam",
      username: "Rupam",
      email: "rupam@gmail.com",
      phone: "91-71-809970",
      website: "rupam.net"
    },
    {
      id: 8,
      name: "Anshu Kumar",
      username: "Anshu",
      email: "anshu@gmail.com",
      phone: "21-098096858",
      website: "anshu.org"
    },
    {
      id: 9,
      name: "Graham Leman",
      username: "Graham",
      email: "graham@gmail.com",
      phone: "011-2222232",
      website: "graham.com"
    },
    {
      id: 10,
      name: "Bret Graham",
      username: "Bharath",
      email: "bharath@gmail.com",
      phone: "31-230-943668",
      website: "bharath.org"
    }
  ];